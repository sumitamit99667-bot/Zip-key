ZapUPI + Firebase integration package
======================================

Files:
- admin.html: existing admin page patched with a manual license-key field per product.
- user.html: existing store patched to create ZapUPI payments and show issued keys in Purchase History.
- functions/: secure backend; ZapUPI secret is stored server-side, and payment success is verified against ZapUPI Order Status API before keys are issued.

IMPORTANT: This is not live until the Firebase Functions backend is deployed and the RTDB rules are reviewed. Do not put the ZapUPI key in either HTML file.

Deploy steps (run in a computer terminal with Firebase CLI installed):
1. Put the contents of this package's functions folder into your Firebase project's functions/ folder.
2. From the Firebase project root, run: firebase use amit-897b6
3. Run: firebase functions:secrets:set ZAPUPI_KEY
   Paste the ZapUPI merchant key into the terminal prompt, not into chat or HTML.
4. Run: cd functions && npm install
5. Run: firebase deploy --only functions
6. In ZapUPI dashboard, configure webhook URL:
   https://us-central1-amit-897b6.cloudfunctions.net/zapupiWebhook
   The backend also sends this URL with each create-order request.
7. Replace the uploaded hosted admin.html and user.html with the patched versions from this package.

Functions endpoint used by the HTML files:
https://us-central1-amit-897b6.cloudfunctions.net/api

Firebase Cloud Functions deployment generally requires the Firebase project to be on the Blaze billing plan. Review billing before enabling it.

Manual license keys:
- Open Admin Panel, edit a product, paste one available key per line in “Manual License Keys”, and save.
- Keys are kept in privateLicenseKeys (not inside the public products record).
- Do not configure broad public read access to privateLicenseKeys or zapupiOrders. The backend uses Admin SDK, so these nodes should not be publicly readable/writable from clients. Review and update RTDB Security Rules before production use.

Payment behavior:
- Server computes price from the Firebase product records; client-provided prices are not trusted.
- Payment is confirmed by calling ZapUPI's Order Status API, not by trusting the browser callback alone.
- A key is consumed only after verified payment. If no key remains, the payment is recorded as paid_key_pending and no fake key is issued; add keys and handle that order manually.
- This implementation supports a cart with multiple products and uses one payment for the calculated cart total. Coupon validation/calculation is performed server-side.
