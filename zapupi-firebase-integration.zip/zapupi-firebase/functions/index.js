const { onRequest } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const admin = require('firebase-admin');
const express = require('express');
const cors = require('cors');

admin.initializeApp();
const db = admin.database();
const ZAPUPI_KEY = defineSecret('zap25cc6b27a160fc5ac4bba415a330b1a0');
const app = express();
app.use(cors({ origin: true }));
app.use(express.json({ limit: '1mb' }));

async function requireUser(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const match = header.match(/^Bearer (.+)$/);
    if (!match) return res.status(401).json({ error: 'Login required.' });
    req.user = await admin.auth().verifyIdToken(match[1]);
    return next();
  } catch (e) {
    return res.status(401).json({ error: 'Your session expired. Please sign in again.' });
  }
}

async function requireAdmin(req, res, next) {
  try {
    const snap = await db.ref('meta/adminSetup').get();
    const adminEmail = snap.exists() ? String(snap.val().adminEmail || '').toLowerCase() : '';
    if (!adminEmail || String(req.user.email || '').toLowerCase() !== adminEmail) {
      return res.status(403).json({ error: 'Admin access required.' });
    }
    return next();
  } catch (e) {
    return res.status(500).json({ error: 'Could not verify admin access.' });
  }
}

function money(value) { return Math.round((Number(value) + Number.EPSILON) * 100) / 100; }
function zapKey() { return ZAPUPI_KEY.value(); }

async function zapupiStatus(orderId) {
  const response = await fetch('https://pay.zapupi.com/api/order-status', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ zap_key: zapKey(), order_id: orderId })
  });
  const json = await response.json().catch(() => ({}));
  if (!response.ok || !json.data) throw new Error(json.message || 'Unable to verify payment with ZapUPI.');
  return json.data;
}

async function processVerifiedPayment(orderId, statusData) {
  const paymentRef = db.ref(`zapupiOrders/${orderId}`);
  let claimedRecord;
  const claim = await paymentRef.transaction(current => {
    if (!current || current.status === 'confirmed' || current.status === 'processing' || current.status === 'failed') return;
    if (current.status !== 'pending') return;
    current.status = 'processing';
    current.processingStartedAt = new Date().toISOString();
    claimedRecord = current;
    return current;
  });
  if (!claim.committed) {
    const latest = (await paymentRef.get()).val() || {};
    return latest.status || 'pending';
  }
  const payment = claim.snapshot.val() || claimedRecord;
  const apiStatus = String(statusData.status || '').toLowerCase();
  if (apiStatus !== 'success') {
    await paymentRef.update({ status: apiStatus === 'failed' ? 'failed' : 'pending', lastStatusCheckAt: new Date().toISOString() });
    return apiStatus === 'failed' ? 'failed' : 'pending';
  }
  const paidAmount = money(statusData.pay_amount ?? statusData.amount);
  if (paidAmount !== money(payment.expectedAmount)) {
    await paymentRef.update({ status: 'amount_mismatch', zapupiAmount: paidAmount, txnId: statusData.txn_id || '', utr: statusData.utr || '' });
    return 'amount_mismatch';
  }

  // Check stock first so a multi-product order does not consume only some keys.
  for (const item of (payment.items || [])) {
    const availableSnap = await db.ref(`privateLicenseKeys/${item.productId}/availableKeys`).get();
    const available = availableSnap.exists() && Array.isArray(availableSnap.val()) ? availableSnap.val().filter(k => typeof k === 'string' && k.trim()) : [];
    if (!available.length) {
      await paymentRef.update({ status: 'paid_key_pending', txnId: statusData.txn_id || '', utr: statusData.utr || '', paidAmount, issue: `No available license key for product ${item.productId}` });
      return 'paid_key_pending';
    }
  }

  const delivered = [];
  for (const item of (payment.items || [])) {
    const keysRef = db.ref(`privateLicenseKeys/${item.productId}/availableKeys`);
    let taken = null;
    const keyClaim = await keysRef.transaction(current => {
      const list = Array.isArray(current) ? current.filter(k => typeof k === 'string' && k.trim()) : [];
      if (!list.length) return;
      taken = list[0];
      return list.slice(1);
    });
    if (!keyClaim.committed || !taken) {
      await paymentRef.update({ status: 'paid_key_pending', txnId: statusData.txn_id || '', utr: statusData.utr || '', paidAmount, issue: `No available license key for product ${item.productId}` });
      return 'paid_key_pending';
    }
    const childRef = db.ref('orders').push();
    const childOrder = {
      productId: item.productId,
      productSnapshot: { title: item.title, imageUrl: item.imageUrl || '', discountedPrice: item.price },
      userId: payment.uid,
      userEmail: payment.userEmail || '',
      amountPaid: item.price,
      finalAmount: item.price,
      status: 'confirmed',
      paymentMethod: 'ZapUPI',
      zapupiOrderId: orderId,
      txnId: statusData.txn_id || '',
      utr: statusData.utr || '',
      createdAt: new Date().toISOString(),
      confirmedAt: new Date().toISOString()
    };
    delivered.push({ childOrderId: childRef.key, productId: item.productId, licenseKey: taken, downloadLink: item.downloadLink || '' });
    await childRef.set(childOrder);
    await db.ref(`users/${payment.uid}/purchases/${childRef.key}`).set({ orderId: childRef.key, productId: item.productId, licenseKey: taken, purchasedAt: new Date().toISOString() });
  }
  await paymentRef.update({ status: 'confirmed', txnId: statusData.txn_id || '', utr: statusData.utr || '', paidAmount, delivered, confirmedAt: new Date().toISOString() });
  if (payment.couponId) {
    const couponRef = db.ref(`coupons/${payment.couponId}/usedCount`);
    await couponRef.transaction(current => Number(current || 0) + 1);
  }
  return 'confirmed';
}

app.post('/create-order', requireUser, async (req, res) => {
  try {
    const productIds = Array.isArray(req.body.productIds) ? [...new Set(req.body.productIds.map(String))] : [];
    if (!productIds.length || productIds.length > 20) return res.status(400).json({ error: 'Choose between 1 and 20 products.' });
    const items = [];
    let subtotal = 0;
    for (const productId of productIds) {
      const snap = await db.ref(`products/${productId}`).get();
      if (!snap.exists()) return res.status(400).json({ error: 'A selected product no longer exists.' });
      const p = snap.val();
      const price = money(p.discountedPrice);
      if (!Number.isFinite(price) || price <= 0) return res.status(400).json({ error: 'Only paid products can be checked out.' });
      items.push({ productId, title: String(p.title || 'Product'), imageUrl: String(p.imageUrl || ''), downloadLink: String(p.downloadLink || ''), price });
      subtotal += price;
    }
    subtotal = money(subtotal);
    let discount = 0;
    let couponId = null;
    const couponCode = String(req.body.couponCode || '').trim().toUpperCase();
    if (couponCode) {
      const couponsSnap = await db.ref('coupons').get();
      const coupons = couponsSnap.val() || {};
      const found = Object.entries(coupons).find(([, c]) => String(c.code || '').toUpperCase() === couponCode);
      if (found) {
        const [id, c] = found;
        const now = Date.now();
        const active = c.isActive && (!c.expiryDate || new Date(c.expiryDate).getTime() > now) && (!(Number(c.usageLimit) > 0) || Number(c.usedCount || 0) < Number(c.usageLimit)) && (!(Number(c.minAmount) > 0) || subtotal >= Number(c.minAmount));
        if (active) {
          discount = c.discountType === 'percentage' ? subtotal * Number(c.discountValue || 0) / 100 : Number(c.discountValue || 0);
          if (Number(c.maxDiscount) > 0) discount = Math.min(discount, Number(c.maxDiscount));
          discount = Math.min(subtotal, money(discount));
          couponId = id;
        }
      }
    }
    const amount = money(Math.max(0, subtotal - discount));
    if (amount <= 0) return res.status(400).json({ error: 'The total must be greater than ₹0 to use ZapUPI.' });
    const orderId = `ORD${Date.now()}${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
    const payment = { orderId, uid: req.user.uid, userEmail: req.user.email || '', items, subtotal, discount, couponId, expectedAmount: amount, status: 'pending', createdAt: new Date().toISOString() };
    await db.ref(`zapupiOrders/${orderId}`).set(payment);
    const response = await fetch('https://pay.zapupi.com/api/create-order', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ zap_key: zapKey(), order_id: orderId, amount: amount.toFixed(2), remark: `Store order | ${req.user.uid}`, webhook_url: 'https://us-central1-amit-897b6.cloudfunctions.net/zapupiWebhook' })
    });
    const data = await response.json().catch(() => ({}));
    const paymentUrl = data.payment_url || data.data?.payment_url;
    if (!response.ok || !paymentUrl) {
      await db.ref(`zapupiOrders/${orderId}`).update({ status: 'create_failed', gatewayResponse: data, updatedAt: new Date().toISOString() });
      return res.status(502).json({ error: data.message || 'ZapUPI could not create the payment order.' });
    }
    await db.ref(`zapupiOrders/${orderId}`).update({ paymentUrl });
    return res.json({ orderId, paymentUrl, amount });
  } catch (e) {
    console.error('create-order error', e);
    return res.status(500).json({ error: 'Could not create payment order. Please try again.' });
  }
});

app.get('/order-status', requireUser, async (req, res) => {
  try {
    const orderId = String(req.query.orderId || '');
    if (!orderId) return res.status(400).json({ error: 'Missing orderId.' });
    const ref = db.ref(`zapupiOrders/${orderId}`);
    const snap = await ref.get();
    if (!snap.exists() || snap.val().uid !== req.user.uid) return res.status(404).json({ error: 'Order not found.' });
    let order = snap.val();
    if (order.status === 'pending') {
      try {
        const statusData = await zapupiStatus(orderId);
        const status = String(statusData.status || '').toLowerCase();
        if (status === 'success' || status === 'failed') {
          await processVerifiedPayment(orderId, statusData);
          order = (await ref.get()).val() || order;
        }
      } catch (e) { console.warn('status poll:', e.message); }
    }
    return res.json({ orderId, status: order.status, delivered: order.status === 'confirmed' ? (order.delivered || []) : [], message: order.status === 'paid_key_pending' ? 'Payment verified, but a license key is unavailable. Contact support.' : undefined });
  } catch (e) {
    console.error('order-status error', e);
    return res.status(500).json({ error: 'Could not check order status.' });
  }
});

app.get('/admin/keys/:productId', requireUser, requireAdmin, async (req, res) => {
  try {
    const snap = await db.ref(`privateLicenseKeys/${req.params.productId}/availableKeys`).get();
    return res.json({ availableKeys: snap.exists() && Array.isArray(snap.val()) ? snap.val() : [] });
  } catch (e) { return res.status(500).json({ error: 'Could not load keys.' }); }
});

app.post('/admin/keys/:productId', requireUser, requireAdmin, async (req, res) => {
  try {
    const keys = Array.isArray(req.body.availableKeys) ? req.body.availableKeys.map(k => String(k).trim()).filter(Boolean) : [];
    if (keys.length > 1000) return res.status(400).json({ error: 'Maximum 1000 available keys per save.' });
    if (keys.some(k => k.length > 300)) return res.status(400).json({ error: 'A license key is too long.' });
    const unique = [...new Set(keys)];
    await db.ref(`privateLicenseKeys/${req.params.productId}/availableKeys`).set(unique);
    return res.json({ saved: unique.length });
  } catch (e) { return res.status(500).json({ error: 'Could not save license keys.' }); }
});

exports.api = onRequest({ secrets: [ZAPUPI_KEY], timeoutSeconds: 60 }, app);

exports.zapupiWebhook = onRequest({ secrets: [ZAPUPI_KEY], timeoutSeconds: 60 }, async (req, res) => {
  try {
    if (req.method !== 'POST') return res.status(200).json({ status: 'ok' });
    const orderId = String(req.body?.order_id || '');
    if (!orderId) return res.status(200).json({ status: 'ok' });
    const orderSnap = await db.ref(`zapupiOrders/${orderId}`).get();
    if (!orderSnap.exists()) return res.status(200).json({ status: 'ok' });
    const incomingStatus = String(req.body?.status || '').toLowerCase();
    if (incomingStatus === 'success' || incomingStatus === 'failed') {
      const statusData = await zapupiStatus(orderId);
      await processVerifiedPayment(orderId, statusData);
    }
    return res.status(200).json({ status: 'ok' });
  } catch (e) {
    console.error('ZapUPI webhook error', e);
    // Return non-200 so ZapUPI can retry delivery when verification fails transiently.
    return res.status(500).json({ status: 'retry' });
  }
});
